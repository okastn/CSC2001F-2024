package serialAbelianSandpile;

import java.util.concurrent.RecursiveAction;
import java.util.concurrent.ForkJoinPool;


class SandpileUpdateTask extends RecursiveAction<Boolean> {
    private Grid grid;
    private int[][] update;
    private int startRow, endRow;
    private static final int CUT = 100; // Adjust based on performance testing

    public SandpileUpdateTask(Grid grid, int startRow, int endRow) {
        this.grid = grid;
        this.update = update;
        this.startRow = startRow;
        this.endRow = endRow;
    }

    @Override
    protected boolean compute() {
        if (endRow - startRow <= CUT) {
            update();
        } else {
            int midRow = (startRow + endRow) / 2;
            SandpileUpdateTask left = new SandpileUpdateTask(grid, startRow, midRow);
            SandpileUpdateTask right = new SandpileUpdateTask(grid, midRow, endRow);
            left.fork();
            boolean leftChanged = left.compute();
            boolean rightChanged = right.join();
            return leftChanged || rightChanged;
           
        }
    }

    private boolean update() {
        boolean changed = false;
        int current;
        for (int i = startRow; i < endRow; i++) {
            for (int j = 1; j < grid.getColumns() + 1; j++) {
                current= grid.get(i, j);
                int newValue = (current % 4) +
                    (grid.get(i-1, j) / 4) +
                    (grid.get(i+1, j) / 4) +
                    (grid.get(i, j-1) / 4) +
                    (grid.get(i, j+1) / 4);
                
                if (newValue != currentValue) {
                    changed = true;
                }
                grid.setGrid(i, j, newValue);
            }
        }
        return changed;
        }
    
}